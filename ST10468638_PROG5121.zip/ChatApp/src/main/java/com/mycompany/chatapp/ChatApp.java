/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapp;
import javax.swing.JOptionPane;


/**
 *
 * @author RC_Student_lab
 */
public class ChatApp {

    public static void main(String[] args) {
           // Step 1: Register user
        String firstName = JOptionPane.showInputDialog("Enter your first name:");
        String lastName = JOptionPane.showInputDialog("Enter your last name:");

        String username = JOptionPane.showInputDialog("Enter username:");
        if (!Login.isValidUsername(username)) {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains underscore and is no more than five characters in length.");
            return;
        } else {
            JOptionPane.showMessageDialog(null, "Username is successfully captured.");
        }

        String password = JOptionPane.showInputDialog("Enter password:");
        if (!Login.isValidPassword(password)) {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            return;
        } else {
            JOptionPane.showMessageDialog(null, "Password is successfully captured.");
        }

        String phoneNumber = JOptionPane.showInputDialog("Enter your cell phone number:");
        if (!Login.isValidPhoneNumber(phoneNumber)) {
            JOptionPane.showMessageDialog(null, "Cell phone number incorrectly formatted or does not contain international code.");
            return;
        } else {
            JOptionPane.showMessageDialog(null, "Cell phone number is successfully added.");
        }

        // Step 2: Login form
        JOptionPane.showMessageDialog(null, "Registration complete. Please login.");

        String loginUsername = JOptionPane.showInputDialog("Enter your username:");
        String loginPassword = JOptionPane.showInputDialog("Enter your password:");

        // Step 3: Check login
        Login login = new Login(username, password); // registered credentials
        if (login.loginUser(loginUsername, loginPassword)) {
            JOptionPane.showMessageDialog(null, "Welcome " + firstName + ", " + lastName + ". It is great to see you again.");
        } else {
            JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again.");
        }
    }

    // Inner class for handling login & validation
    static class Login {
        private String registeredUsername;
        private String registeredPassword;

        public Login(String registeredUsername, String registeredPassword) {
            this.registeredUsername = registeredUsername;
            this.registeredPassword = registeredPassword;
        }

        public boolean loginUser(String enteredUsername, String enteredPassword) {
            return registeredUsername.equals(enteredUsername) && registeredPassword.equals(enteredPassword);
        }

        public static boolean isValidUsername(String username) {
            return username.contains("_") && username.length() <= 5;
        }

        public static boolean isValidPassword(String password) {
            String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*(),.?\":{}|<>]).{8,}$";
            return password.matches(regex);
        }

        public static boolean isValidPhoneNumber(String phoneNumber) {
             return phoneNumber.matches("^\\+[0-9]{1,4}[0-9]{9}$") && phoneNumber.length()== 12;
        }
    }
}
