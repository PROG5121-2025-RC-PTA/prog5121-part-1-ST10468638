/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chatapp;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author RC_Student_lab
 */
public class ChatApp {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        
         // Step 1: Registration
        String firstName = JOptionPane.showInputDialog("Enter your first name:");
        String lastName = JOptionPane.showInputDialog("Enter your last name:");

        String username = JOptionPane.showInputDialog("Enter username:");
        if (username == null || !Login.isValidUsername(username)) {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted. It must contain an underscore and be no more than 5 characters.");
            return;
        }

        String password = JOptionPane.showInputDialog("Enter password:");
        if (password == null || !Login.isValidPassword(password)) {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted; it must contain at least 8 characters, a capital letter, a number, and a special character.");
            return;
        } else {
            JOptionPane.showMessageDialog(null, "Password successfully captured.");
        }

        String phoneNumber = JOptionPane.showInputDialog("Enter your cell phone number:");
        if (phoneNumber == null || !Login.isValidPhoneNumber(phoneNumber)) {
            JOptionPane.showMessageDialog(null, "Cell phone number incorrectly formatted or does not contain international code.");
            return;
        } else {
            JOptionPane.showMessageDialog(null, "Cell phone number successfully captured.");
        }

        JOptionPane.showMessageDialog(null, "Registration successful! Please log in.");

        // Step 2: Login
        String loginUsername = JOptionPane.showInputDialog("Enter your username:");
        String loginPassword = JOptionPane.showInputDialog("Enter your password:");

        Login login = new Login(username, password);
        if (!login.loginUser(loginUsername, loginPassword)) {
            JOptionPane.showMessageDialog(null, "Login failed. Incorrect username or password.");
            return;
        } else {
            JOptionPane.showMessageDialog(null, "Welcome " + firstName + " " + lastName + ", it is great to see you again.");
            JOptionPane.showMessageDialog(null, "Welcome to QuickChart");

        }

        Message messageApp = new Message();
        boolean keepGoing = true;

        while (keepGoing) {
            String[] options = {"Send Messages", "Show Recently Sent Messages", "Quit"};
            String choice = (String) JOptionPane.showInputDialog(null, "Choose an option:", "Main Menu", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

            if (choice == null || choice.equals("Quit")) {
                keepGoing = false;
                break;
            }

            switch (choice) {
                case "Send Messages":
                    int messageLimit = 0;
                    try {
                        messageLimit = Integer.parseInt(JOptionPane.showInputDialog("How many messages do you want to send?"));
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "Invalid number entered.");
                        continue;
                    }

                    for (int i = 0; i < messageLimit; i++) {
                        String recipient = JOptionPane.showInputDialog("Enter recipient phone number:");
                        if (recipient == null || Message.checkRecipientCell(recipient) == 0) {
                            JOptionPane.showMessageDialog(null, "Invalid recipient number. Must start with '+' and be 11-12 digits.");
                            continue;
                        }

                        String messageText = JOptionPane.showInputDialog("Enter your message (less than 250 characters):");
                        if (messageText == null || messageText.length() > 250) {
                            JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters.");
                            continue;
                        } else {
                            JOptionPane.showMessageDialog(null, "Message sent");
                        }

                        String messageId = messageApp.generateMessageID();
                        if (!Message.checkMessageID(messageId)) {
                            JOptionPane.showMessageDialog(null, "Generated message ID is invalid.");
                            continue;
                        }

                        String hash = messageApp.createMessageHash(messageId, messageText);
                        String option = messageApp.sendMessageOption();
                        if (option == null) continue;

                        if (option.equals("Send Message")) {
                            messageApp.addMessage(messageId, hash, recipient, messageText);
                            JOptionPane.showMessageDialog(null, "Message sent:\n\nMessageID: " + messageId + "\nMessage Hash: " + hash + "\nRecipient: " + recipient + "\nMessage: " + messageText);
                        } else if (option.equals("Store Message to send later")) {
                            messageApp.storeMessage(messageId, hash, recipient, messageText);
                        } else {
                            JOptionPane.showMessageDialog(null, "Message discarded.");
                        }
                    }
                    break;

                case "Show Recently Sent Messages":
                    JOptionPane.showMessageDialog(null, "Coming Soon.");
                    break;
            }
        }

        JOptionPane.showMessageDialog(null, messageApp.printMessages());
        JOptionPane.showMessageDialog(null, "Total messages sent: " + messageApp.returnTotalMessages());
    }
}

class Login {
    private String registeredUsername;
    private String registeredPassword;

    public Login(String registeredUsername, String registeredPassword) {
        this.registeredUsername = registeredUsername;
        this.registeredPassword = registeredPassword;
    }

    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return registeredUsername.equals(enteredUsername) && registeredPassword.equals(enteredPassword);
    }

    public static boolean isValidUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public static boolean isValidPassword(String password) {
        return password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$");
    }

    public static boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber != null && phoneNumber.matches("^\\+\\d{10,11}$");
    }
}

class Message {
    private List<String> messageList = new ArrayList<>();
    private int totalMessages = 0;
    private JSONArray storedMessages = new JSONArray();

    public String generateMessageID() {
        Random rand = new Random();
        long num = 1000000000L + (long)(rand.nextDouble() * 9000000000L); // Ensures 10-digit number
        return String.valueOf(num);
    }

    public static boolean checkMessageID(String id) {
        return id.length() == 10 && id.matches("\\d+");
    }

    public static int checkRecipientCell(String cell) {
    // Accepts + followed by 11 digits (total 12 characters) or more
    return (cell != null && cell.matches("^\\+\\d{11,13}$")) ? 1 : 0;
}


    public String createMessageHash(String id, String message) {
        String[] words = message.trim().split("\\s+");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : first;
        return (id.substring(0, 2) + ":" + totalMessages + ":" + first.toUpperCase() + last.toUpperCase());
    }

    public String sendMessageOption() {
        Object[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
        return (String) JOptionPane.showInputDialog(null, "Choose an option:", "Message Options", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
    }

    public void addMessage(String id, String hash, String recipient, String message) {
        String full = "MessageID: " + id + "\nMessage Hash: " + hash + "\nRecipient: " + recipient + "\nMessage: " + message;
        messageList.add(full);
        totalMessages++;
    }

    public String printMessages() {
        StringBuilder builder = new StringBuilder("Messages Sent:\n\n");
        for (String msg : messageList) {
            builder.append(msg).append("\n\n");
        }
        return builder.toString();
    }

    public int returnTotalMessages() {
        return totalMessages;
    }

    public void storeMessage(String id, String hash, String recipient, String message) {
        JSONObject obj = new JSONObject();
        obj.put("messageID", id);
        obj.put("messageHash", hash);
        obj.put("recipient", recipient);
        obj.put("message", message);

        storedMessages.add(obj);

        try (FileWriter file = new FileWriter("messages.json")) {
            file.write(storedMessages.toJSONString());
            file.flush();
            JOptionPane.showMessageDialog(null, "Message stored to JSON.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error storing message: " + e.getMessage());
        }
    }
}